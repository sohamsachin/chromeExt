
var availableLanguages = {
    en: 'English',
    hi: 'Hindi',
    de: 'German',
    fr: 'French',
    ar: 'Arabic'
};

var webPagelanguage = "en";

populateSelectOptions = function () {
    var select = document.getElementById("selectedLang");
    for (key in availableLanguages) {
        if (key != webpageLanguage) {
            var option = new Option(availableLanguages[key], key);
            option.className = "language-option";
            select.options[select.options.length] = option;
        }
    }
}

const setLangInfo = info => {
    document.getElementById('pageLanguage').textContent = availableLanguages[info.pageLanguage];
    webpageLanguage = info.pageLanguage;
    populateSelectOptions();
};


// Once the DOM is ready...
window.addEventListener('DOMContentLoaded', () => {
    // ...query for the active tab...
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, tabs => {
        // ...and send a request for the DOM info...
        chrome.tabs.sendMessage(
            tabs[0].id,
            { from: 'popup', subject: 'LanguageInfo' },
            // ...also specifying a callback to be called 
            //    from the receiving end (content script).
            setLangInfo);
    });
});

changeWebpagelanguage = function (newlanguage) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { from: "popup", subject: "changeLanguage", newlanguage: newlanguage });
    });
}

restoreOriginalState = function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { from: "popup", subject: "restoreOriginal" });
    });
}



$(function () {
    $('#restoreButton').click( function () {
        restoreOriginalState();
    });

   /* $('#selectedLang').change(function () {
        var selectedLang = $('#selectedLang').val();
        changeWebpagelanguage(selectedLang);
        var t = "#selectedLang option[value='"+selectedLang+"']";
        $(t).remove();
    });*/

    $('#selectedLang').change(function () {
        $(".language-option").show();
        $( "#selectedLang option:selected").hide();
    });
});




