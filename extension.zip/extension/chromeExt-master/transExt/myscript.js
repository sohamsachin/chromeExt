function addElement() {
  // create a new div element 
  var newDiv = document.createElement("div");
  newDiv.setAttribute("id", "google_translate_element");
  // add the newly created element into the DOM 
  document.body.appendChild(newDiv);
}

addElement();

function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'en',
    autoDisplay: false,
    includedLanguages: 'en,hi,de,fr,ar',
    layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL
  }, 'google_translate_element');
}


document.addEventListener('popupChangeListner', function (e) {
  var data = e.detail;
  console.log(" data from content :" + data.subject);
  if (data.subject == "changelanguage") {
    changeLanguageTo(data.newlanguage);
  } else if (data.subject == "restoreOriginal") {
    restoreOriginalState();
  }
});


changeLanguageTo = function(newLang) {
  var selectField = document.querySelector("#google_translate_element select");

  for (var i = 0; i < selectField.children.length; i++) {
    var option = selectField.children[i];
    // find desired langauge and change the former language of the hidden selection-field 
    if (option.value == newLang) {

      selectField.selectedIndex = i;
      // trigger change event afterwards to make google-lib translate this side
      selectField.dispatchEvent(new Event('change'));
      break;
    }
  }
}


restoreOriginalState = function () {
  var iframe = document.getElementsByClassName('goog-te-banner-frame skiptranslate')[0];
  if (!iframe) return;

  var innerDoc = iframe.contentDocument || iframe.contentWindow.document;
  var restore_el = innerDoc.getElementsByTagName("button");

  for (var i = 0; i < restore_el.length; i++) {
    if (restore_el[i].id.indexOf("restore") >= 0) {
      restore_el[i].click();
      var close_el = innerDoc.getElementsByClassName("goog-close-link");

      close_el[0].click();
      return;
    }
  }
}